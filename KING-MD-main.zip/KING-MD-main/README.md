</p>
<p align="center">
  <a href="https://chat.whatsapp.com/JIJplkiYyrFE4dyFGade43">
    <img alt=Support height="350" src="https://telegra.ph/file/a6b9bbde7feaa92c69c7b.jpg"> 
    </p>
<h1 align="center">    ꪶKING-MD-BOTꫂ
</h1>
<p align="center"> 
  
<p align="center"> A Multi Device Whatsapp Bot Create By Naveed Dogar To Do Everything That Is Possible On WhatsApp
 
  </a>
</p>
<p align="center">
<a href="https://github.com/naveeddogar"><img title="Author" src="https://img.shields.io/badge/KING_MD-MULTI_DEVICE-black?style=for-the-badge&logo=github"></a>
<p/>



---  

</p>


   <p align="center">
  <a href="https://github.com/naveeddogar/KING-MD/fork">
    <img src="https://img.shields.io/github/forks/naveeddogar/KING-MD?label=Fork&style=social">
   
  <a href="https://github.com/naveeddogar/KING-MD/stargazers">
    <img src="https://img.shields.io/github/stars/naveeddogar/KING-MD?style=social">
      

 <p align="center">
  <a href="https://github.com/naveeddogar">
    <img src="https://img.shields.io/badge/OWNER-naveeddogar-black?style=social&logo=github&label=Owner">
   
  <a href="https://github.com/naveeddogar/KING-MD/blob/main/LICENSE">
    <img src="https://img.shields.io/github/license/naveeddogar/KING-MD?style=social">
   
 

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{naveeddogar}/count.svg" alt="naveeddogar :: Visitor's Count" /></p>
<p align="center">
 <a href="https://whatsapp.com/channel/0029Va66s2IJENxvTJjUtM1w" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/Support Channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
 <a href="https://tinyurl.com/Technical-Naveed-Official" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Subscribe My Yt-red?style=for-the-badge&logo=youtube&logoColor=white" />
  </a>
</p>



# DEPLOY SETUP


## 1 *`⨷ FORK THIS REPO`*
<a href='https://github.com/naveeddogar/KING-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=graphql&logoColor=white'/></a>

## 2 *`⨷ SCAN OR PAIR QR`*
<a href='https://king-md-session.onrender.com/' target="_blank"><img alt='scan repo' src='https://img.shields.io/badge/Get Session Id-black?style=for-the-badge&logo=flutter&logoColor=white'/></a>

## 3 *`⨷ NOW DEPLOY`*

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://heroku.com/deploy' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


#### DEPLOY TO KOYEB

1. If You don't have a account in Koyeb. Create a account.
    <br>
<a href='https://app.koyeb.com/auth/signup' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=koyeb' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/SuhailTechInfo/Suhail-black?style=for-the-badge&logo=koyeb&logoColor=white"></a>


#### DEPLOY TO CODESPACE

1. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>


#### DEPLOY TO RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

#### DEPLOY TO MONGENIUS

1. If You don't have a account in Mongenius. Create a account.
    <br>
<a href='https://studio.mogenius.com/user/registration' target="_blank"><img alt='Mongenius' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>


#### DEPLOY TO REPLIT

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://replit.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://replit.com/github/naveeddogar/KING-MD' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

---


 <details close>
<summary>𝙉𝙀𝙒 𝙐𝙋𝘿𝘼𝙏𝙀 & 𝙁𝙀𝘼𝙏𝙐𝙍𝙀𝙎 </summary>

- ***King-Md v1.2.9 Fixing***
- *Fixed `All Ai` Commands*
- *Fixed `Spotify` Command*
- *Fixed `All Anime` Commands*
- *Fixed `Insta,Fb,Tiktok` Commands*
- *Fixed All Not Working Commands, Due To Api*
- *Added My Own Api In Bot https://api.maher-zubair.tech*
- ***King-Md v1.2.9 Released***
- *Added `Pair Code` For Session ID*
- *Added New `Session ID` For Bot*
- *Added New `Qr`*
- *Added Massive Anime*
- *Added 11 AI*
- *Added 18 GFX*
- *Added Twitter Templates On Celebreties*
- *Added `Afk` Cmd*
- *Added `Teddy` Cmd*
- *Fixed `Insta` Cmd*
- *Fixed `Tiktok` Cmd*
- *Fixed `Facebook` Cmd*
- *Changed `Apk` Cmd Style*
- *Changed `Hack` Cmd Style*
- *Changed `Uptime` Cmd Style*
- *Added Some New `Logos` Cmds*
- *Added `Steal` Cmd For Sticker*
- *Added `Islamic` Cmd Wallpaper*
- *Added `Nasa` Cmd To Get Nasa News*
- *Added `Tech` Cmd To Get Tech News*
- *Fixed `Bgm` Cmd Added on/off Case*
- *Fixed `Welcome` Cmd Added Off Case*
- *Fixed `Goodbye` Cmd Added Off Case*
- *Added `Mode` Cmd To Change Bot Mode*
- *Renamed `plugins` Cmd To `Allplugins`*
- *Added `Theme` Cmd To Change Bot Theme*
- *Added `Ip` Cmd For Ip Address Stalking*
- *Added `pp` Cmd To Change/Remove Your Dp*
- *Added `Sticky` Cmd To Download Stickers*
- *Fixed `Antibot` Cmd Added Delete Option*
- *Fixed `Antilink` Cmd Added Delete Option*
- *Fixed `Cpu` Cmd To Get Your Server Info*
- *Added `Poetry` Cmd For Urdu/Hindi Poetry*
- *Added `Gc` Cmd To Get Group Full Details*
- *Added `Github` Cmd To Stalk Github Users*
- *Added `Setprefix` Cmd To Change Bot Prefix*
- *Added `Category` Cmd To Get All Categories*
- *Moved `Media` Category To External PLugins*
- *Added `Antiwords` Cmd To Prevent Bad Words*
- *Added `#` Cmd To Download Someone's Status*
- *Added `Calc` Cmd For Simple MAth Operations*
- *Added `Lyrics` Cmd To Get Lyrics Of Any Song*
- *Added `typing` Cmd To Turn On/Off Auto-Typing*
- *Fixed `Help` Cmd To Get Details About Any Cmd*
- *Added `Spotify` Cmd To Download Spotify Songs*
- *Added `Online` Cmd To Turn On/Off Always-Online*
- *Added `Tempmail` Cmd To Generate Mails/Get Info*
- *Added `Plugin` Cmd To Get All External Plugins*
- *Added `Npm1` Cmd To Get Info About Npm Packages*
- *Added `Reaction` Cmd To Turn On/Off Auto-Reaction*
- *Added `Read` Cmd To Turn On/Off Auto-Read Messages*
- *Added `Stssaver` Cmd To Auto-Download Your Statuses*
- *Added `Stsview` Cmd To Turn On/Off Auto-Status View*
- *Added `Recording` Cmd To Turn On/Off Auto-Recording*
- *Added `Insult` Cmd To Insult Someone By Mention/Reply*
- *Added `Wamod` Cmd To Download Official Moded Whatsapps*
- *Added `Levelup` Cmd To Turn On/Off Auto Levelup-Message*
- *Added `Flirt` Cmd To Flirt With Someone By Mention/Reply*
- *Added `Lines` Cmd To Throw Lines At Someone By Mention/Reply*

</details>



<h2 align="center"> ⭐ 𝑺𝒕𝒂𝒓 𝑻𝒉𝒊𝒔 𝑹𝒆𝒑𝒐 𝑰𝒇 𝒀𝒐𝒖 𝑳𝒊𝒌𝒆 𝑲𝒊𝑵𝒈 𝑴𝑫 
</h2>


<p align="center"> If You Need Any Help Or Any Problem Please Create An <a href="https://github.com/naveeddogar/KING-MD/issues">Issue & Problem</a></p>

<h3 align="center"> <a href="https://github.com/naveeddogar/KING-MD/tree/main/temp">Click Here To Get External Plugins</a></h3> 

 
### `🧡 𝘛𝘩𝘢𝘯𝘬𝘴 𝘛𝘰`
- ***Suhail***
- ***SamPandy***
- ***Zubair***
- ***Who Helping Me***
- ***Who Using This Bot***
- ***Support Me By Subscribe On Yt [Yt Channel](https://tinyurl.com/Technical-Naveed-Official)***

## ```📜 𝘋𝘪𝘴𝘤𝘭𝘢𝘪𝘮𝘦𝘳```

- ***I will only Assist You in Bot Deployment and Hosting, Not in Bot Modifying.***
- ***This Bot [KING-MD](https://github.com/naveeddogar/KING-MD) Has Been Made Under The [Apache-2.0 license](https://github.com/naveeddogar/KING-MD/blob/main/LICENSE).***

- ***This Bot Is Only For Fun and Helps***
