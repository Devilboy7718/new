
<h1 align="center"> King Md Plugins </h1>
<div align="center">
<br /> 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=naveeddogar&label=Visitors%20count&color=10d9c3&style=plastic" alt="lyfe-plugin-list" /> </p>


ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://raw.githubusercontent.com/SecktorBot/Brandimages/main/secktor.png)](https://whatsapp.com/channel/0029Va66s2IJENxvTJjUtM1w)
  <div align="center"  
<h4 align="center">Plugins</h1>

---

- Create your own plugin and join group to add that plugin in repo.

---

<h4 align="center">  Pm-Permit </h1>

Pm Permit Protection
```
https://gist.github.com/naveeddogar/2bc143944d73b6a8f00cc4d34ce7b436/raw
```


---

More Coming Soon
